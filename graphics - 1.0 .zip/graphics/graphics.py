import unittest, pygame, sys
from pygame.locals import *
class draw_rect():
    def __init__(self, rect_x, rect_y, rect_height, rect_width, color, fill_screen, rect_return):
        self.rect_x = rect_x
        self.rect_y = rect_y
        self.rect_height = rect_height
        self.rect_width = rect_width
        self.rect_return = rect_return
        self.color = color
        self.fill_screen = fill_screen
    def show_rect(self):
        pygame.draw.rect(self.fill_screen, self.color, (self.rect_x, self.rect_y, self.rect_height , self.rect_width), self.rect_return)
    def show_rect_test(self):
        pygame.draw.rect(self.fill_screen, (0, 0, 0), (0, 0, 50, 50), 0)
class draw_string_rect():
    def __init__(self, rect_name, range, rect_boolbean):
        self.rect_name = rect_name
        self.range = range
        self.rect_boolbean = rect_boolbean
        if range <= 2:
            print("GetRectsError:Range don't <= 2.")
    def show_string_rect(self):
        str_rect = self.rect_name + "\t"
        rect = str_rect * self.range
        if self.rect_boolbean == True:
            for i in range(1, self.range + 1):
                print(str(rect),"\n")
        elif self.rect_boolbean == False:
            for i in range(1, self.range + 1):
                print(rect)
    def show_string_rect_frame(self):
        min_rect_range = self.range - 2
        str_rect_frame = " " * len(self.rect_name) * min_rect_range
        min_rect_space_range = self.range - 2
        rect_space_range = "\t" * min_rect_space_range
        str_rect = self.rect_name + "\t"
        rect = str_rect * self.range
        if self.rect_boolbean == True:
            print(str(rect), "\n")
            for rf in range(1, self.range - 1):
                print(str(self.rect_name + str_rect_frame + rect_space_range + self.rect_name) + "\n")
        elif self.rect_boolbean == False:
            print(rect)
            for rf in range(1, self.range - 1):
                print(str(self.rect_name + str_rect_frame + rect_space_range + self.rect_name))
        print(str(rect), "\n")
    def show_string_rect_test(self, rect_boolbean):
        print("\nname:'*',range:5(This is a test!)\n")
        if self.rect_boolbean == True:
            for t in range(1, 6):
                print("*\t" * 5,"\n")
        elif self.rect_boolbean == False:
            for t in range(1, 6):
                print("*\t" * 5)
    def show_string_rect_frame_test(self, rect_boolbean):
        rect_frame_name_test_show = "i\t"
        print("\nname:'i',range:5(This is a test!)\n")
        if self.rect_boolbean == True:
            print(str(rect_frame_name_test_show * 5), "\n")
            rect_frame_name_test_show_space = "\t" * 3
            for rt in range(1, 4):
                print(str(rect_frame_name_test_show + rect_frame_name_test_show_space + rect_frame_name_test_show), "\n")
            print(str(rect_frame_name_test_show * 5), "\n")
        elif self.rect_boolbean == False:
            print(rect_frame_name_test_show * 5)
            rect_frame_name_test_show_space = "\t" * 3
            both_rect_frame = rect_frame_name_test_show + rect_frame_name_test_show_space + rect_frame_name_test_show
            for rt in range(1, 4):
                print(both_rect_frame)
            print(str(rect_frame_name_test_show * 5), "\n")
class draw_line():
    def __init__(self, line_width, line_pos_xy1,line_pos_xy2, line_color, line_fill_screen):
        self.line_width = line_width
        self.line_pos_xy1 = line_pos_xy1
        self.line_pos_xy2 = line_pos_xy2
        self.line_color = line_color
        self.line_fill_screen = line_fill_screen
    def show_line(self):
        pygame.draw.line(self.line_fill_screen, self.line_color, self.line_pos_xy1, self.line_pos_xy2, self.line_width)
    def show_line_test(self):
        line_test_screen = pygame.display.set_mode((500, 500))
        pygame.display.set_caption("show_line_test")
        line_test_screen.fill((255, 255, 255))
        while True:
            for linetestevent in pygame.event.get():
                if linetestevent.type == QUIT:
                    sys.exit()
            pygame.draw.line(line_test_screen, (0, 0, 0), (0, 0), (500, 500))
            pygame.display.update()
class draw_string_line():
    def __init__(self, line_name, enter_line, line_enter_range, line_style, *line_boolbean):
        self.line_name = line_name
        self.enter_line = enter_line
        self.line_style = line_style
        self.line_enter_range = line_enter_range
        self.line_boolbean = line_boolbean
    def show_string_line(self):
        if self.line_style == "across":
            if self.line_boolbean == False:
                enter_lines = "\n" * self.enter_line
                print(enter_lines)
                line_enter_ranges = self.line_name * self.line_enter_range
                print(line_enter_ranges)
            elif self.line_boolbean == True:
                enter_lines = "\n" * self.enter_line
                print(enter_lines)
                line_enter_ranges = str(self.line_name) + " "
                line_enter_ranges = line_enter_ranges * self.line_enter_range
                print(line_enter_ranges)
        elif self.line_style == "vertical":
            if self.line_boolbean == True:
                left_line_name = str(self.line_name) + "\n"
                left_line_name = left_line_name * self.line_enter_range
                print(left_line_name)
            elif self.line_boolbean == False:
                left_line_name = self.line_name * self.line_enter_range
                print(left_line_name)
class Text():
    def __init__(self, text, fontsize, font_color, font_boolbean, font_xy, fill_screen):
        self.text = text
        self.fontsize = fontsize
        self.font_color = font_color
        self.font_boolbean = font_boolbean
        self.font_xy = font_xy
        self.fill_screen = fill_screen
    def show_text(self):
        mf = pygame.font.SysFont(None, self.fontsize)
        writes_text = mf.render(self.text, self.font_boolbean, self.font_color)
        self.fill_screen.blit(writes_text, self.font_xy)
    def show_minecraft_font(self):
        mcfont = pygame.font.SysFont("Minecraft.ttc", self.fontsize)
        mcfont = mcfont.render(self.text, True, self.font_color)
        self.fill_screen.blit(mcfont, self.font_xy)

class button():
    def __init__(self, posx, posy, length, width, text, bfont, color, textcolor=(0, 0, 0)):
        self.posx = posx
        self.posy = posy
        self.color = color
        self.length = length
        self.width = width
        self.tcolor = textcolor
        self.font = bfont
        self.text = text
        if self.tcolor == "opposite":
            tcl = []
            for c in color:
                tcl.append(255-c)
            self.textcolor = (tcl[0], tcl[1], tcl[2])
        else:
            self.textcolor = textcolor
        self.rect = pygame.Rect(self.posx, self.posy, length, width)
    def show(self, scr):
        if self.color:
            scr.fill(self.color, self.rect)
        text = self.font.render(self.text, True, self.textcolor)
        text_rect = text.get_rect()
        text_rect.centerx = self.posx+self.length//2
        text_rect.centery = self.posy+self.width//2
        scr.blit(text, text_rect)
    def pressed(self, event):
        if event.type == MOUSEBUTTONDOWN:
            if button == 1 or 3:
                mousedownx, mousedowny = event.pos
                if self.posx <= mousedownx <= self.posx+self.length and self.posy <= mousedowny <= self.posy+self.width:
                    return True
                else:
                    return False
    def color_update(self):
        if self.tcolor == "opposite":
            tcl = []
            for c in self.color:
                tcl.append(255-c)
            self.textcolor = (tcl[0], tcl[1], tcl[2])
